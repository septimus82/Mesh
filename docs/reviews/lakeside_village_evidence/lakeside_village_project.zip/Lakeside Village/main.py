"""Lakeside Village: run the game with `python main.py` (or press Play in Mesh Studio)."""


def main() -> None:
    # The engine is imported here, after the DPI mode is set: pyglet fixes it when it
    # loads, and Mesh draws at a stable scale only when Windows doesn't rescale it.
    from engine.dpi_bootstrap import set_process_dpi_unaware

    set_process_dpi_unaware()

    from engine.config import load_config
    from engine.game import GameWindow
    from engine.game_runtime.scene_flow import resolve_game_start_scene

    config = load_config()
    window = GameWindow(
        width=config.width,
        height=config.height,
        title=config.title,
        fullscreen=config.fullscreen,
        vsync=config.vsync,
        config=config,
        config_path="config.json",
    )
    start = config.main_menu_scene or resolve_game_start_scene(
        engine_config=config, world_controller=getattr(window, "world_controller", None)
    ) or config.start_scene
    window.load_scene(start)
    window.run()


if __name__ == "__main__":
    main()
